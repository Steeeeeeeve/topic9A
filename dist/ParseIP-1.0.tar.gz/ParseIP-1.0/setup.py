from setuptools import setup

setup(
    name = "ParseIP",
    version= "1.0",
    description= "Scrapes your IP address using check ip website",
    author= "Steven Hurkett",
    author_email= "shurkett@academic.rrc.ca",
    py_modules = ["ParseIP"],
)